package com.hong.spbbs.util;

import org.springframework.jdbc.core.JdbcTemplate;

public class Static {
	
	public static JdbcTemplate template;

}
