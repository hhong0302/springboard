package com.hong.spbbs.command;

import org.springframework.ui.Model;

public interface SpCommand {
	
	public void execute(Model model);

}
