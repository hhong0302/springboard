$(function()
{
	$("#content").summernote({
		placeholder:"내용을 입력하세요.",
		tabsize:2,
		height:300
	});
});